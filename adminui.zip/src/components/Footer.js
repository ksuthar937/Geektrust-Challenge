import "./Footer.css";

function Footer() {
  return (
    <footer>
      <div className="container">©2023 AdminUI All rights reserved.</div>
    </footer>
  );
}

export default Footer;
